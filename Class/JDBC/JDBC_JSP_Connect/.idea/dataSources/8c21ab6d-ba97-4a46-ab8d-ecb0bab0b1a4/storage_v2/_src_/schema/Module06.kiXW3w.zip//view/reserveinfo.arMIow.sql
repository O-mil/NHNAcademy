create definer = root@localhost view reserveinfo as
select `p`.`PassengerNo`   AS `PassengerNo`,
       `p`.`PassengerName` AS `PassengerName`,
       `p`.`Grade`         AS `Grade`,
       `p`.`Age`           AS `Age`,
       `r`.`ReserveDate`   AS `ReserveDate`,
       `f`.`FlightNo`      AS `flightNO`
from ((`module06`.`passenger` `p` join `module06`.`reservation` `r`
       on ((`p`.`PassengerNo` = `r`.`PassengerNo`))) join `module06`.`flight` `f`
      on ((`f`.`FlightNo` = `r`.`FlightNo`)));

grant select on table reserveinfo to Celine;

