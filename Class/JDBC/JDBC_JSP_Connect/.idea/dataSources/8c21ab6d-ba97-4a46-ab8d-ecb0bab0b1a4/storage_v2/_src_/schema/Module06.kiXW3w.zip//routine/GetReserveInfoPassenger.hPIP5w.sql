create
    definer = root@localhost procedure GetReserveInfoPassenger(IN passenger int)
BEGIN
	SELECT p.PassengerNo, p.PassengerName, p.Grade, p.Age, r.ReserveDate, f.flightNO
    FROM Passenger AS p INNER JOIN Reservation AS r ON p.passengerNO = r.PassengerNO
		INNER JOIN Flight AS f ON f.flightNo = r.flightNo
	WHERE p.PassengerNo = passenger;
END;

