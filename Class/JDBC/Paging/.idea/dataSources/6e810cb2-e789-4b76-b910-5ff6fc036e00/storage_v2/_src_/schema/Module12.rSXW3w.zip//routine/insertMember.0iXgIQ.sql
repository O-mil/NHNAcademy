create
    definer = root@localhost procedure insertMember()
BEGIN
	DECLARE i int DEFAULT 1;
    WHILE (i <= 5000) DO
		INSERT INTO Members() VALUES();
        SET i = i + 1;
	END WHILE;
END;

