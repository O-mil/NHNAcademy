package com.example.nhnmart.mart;
import java.util.ArrayList;

public class BuyList {
    private final ArrayList<Item> items = new ArrayList<>();

    public void add(Item item) {
        items.add(item);
    }
    public ArrayList<String> getItemList(){
        ArrayList<String> name = new ArrayList<>();
        for(int i=0;i<items.size();i++){
            for(int j=0;j<items.get(i).amount;j++){
                name.add(items.get(i).name);
            }
        }
        return name;
    }
    
    public int getSize(){
        return items.size();
    }

    public static class Item {
        private final String name;

        private final int amount;
        public Item(String name, int amount) {
            this.name = name;
            this.amount = amount;
        }
    }
}
