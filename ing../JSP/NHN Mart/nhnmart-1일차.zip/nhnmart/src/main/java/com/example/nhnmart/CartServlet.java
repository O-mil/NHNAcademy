package com.example.nhnmart;

import com.example.nhnmart.mart.*;
import com.example.nhnmart.util.MartUtils;
import lombok.extern.slf4j.Slf4j;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;


@Slf4j
public class CartServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html");
        Basket basket = (Basket)getServletContext().getAttribute("basket");
        int totalPrice = (Integer) getServletContext().getAttribute("totalPrice");
        try(PrintWriter writer = resp.getWriter()) {
            writer.println("<!DOCTYPE html>");
            writer.println("<html>");
            writer.println("<head>");
            writer.println("</head>");
            writer.println("<body>");
            writer.println("<ul>");
            while(basket.it.hasNext()){
                Food food = basket.it.next();
                writer.println("<p>"+food.getName()+"</p><br/>");
            }
            writer.println("</ul>");
            writer.println("<h2>총가격"+totalPrice+"입니다.</h2>");
            writer.println("</body>");
            writer.println("</html>");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        totalPrice = 0;
        getServletContext().setAttribute("totalPrice",totalPrice);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html");

        String[] onion = req.getParameterValues("onion");
        String[] egg = req.getParameterValues("egg");
        String[] greenOnion = req.getParameterValues("greenOnion");
        String[] apple = req.getParameterValues("apple");
        ArrayList<String> list = new ArrayList<>();
        if(!Objects.isNull(onion)){
            for(String str : onion){
                list.add(str);
                log.info(str);
            }
        }
        if(!Objects.isNull(egg)){
            for(String str : egg){
                list.add(str);
                log.info(str);
            }
        }
        if(!Objects.isNull(greenOnion)){
            for(String str : greenOnion){
                list.add(str);
                log.info(str);
            }
        }
        if(!Objects.isNull(apple)){
            for(String str : apple){
                list.add(str);
                log.info(str);
            }
        }

        FoodStand foodstand = (FoodStand)getServletContext().getAttribute("foodStand");
        MartUtils.makeBasket(list,getServletContext());
        Basket basket = (Basket)getServletContext().getAttribute("basket");
        basket.setIt();
        while(basket.it.hasNext()){
            Food food = (Food)basket.it.next();
            try{
                foodstand.sell(food);
            }catch(Exception e){
            }
        }
        try(PrintWriter writer = resp.getWriter()) {
            writer.println("<!DOCTYPE html>");
            writer.println("<html>");
            writer.println("<head>");
            writer.println("</head>");
            writer.println("<body>");
            writer.println("<h2>장바구니에 물품을 담았습니다.</h2>");
            writer.println("<a href='/cart'>장바구니</a>");
            writer.println("</body>");
            writer.println("</html>");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
