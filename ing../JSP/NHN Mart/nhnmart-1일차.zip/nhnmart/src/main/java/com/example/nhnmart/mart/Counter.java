package com.example.nhnmart.mart;

public class Counter {
    private Basket basket;
    private FoodStand foodstand;
    private int price;

    public Counter(Basket basket,FoodStand foodstand){
        this.basket = basket;
        this.foodstand = foodstand;
    }
    public int getPrice(){
        return price;
    }
    public void bill(){
        basket.setIt();
        price = 0;
        while(basket.it.hasNext()){
            Food food = (Food)basket.it.next();
            try{
                foodstand.sell(food);
                price += food.getPrice();
            }catch(Exception e){
            }
        }
        System.out.println("총가격은 "+price+"입니다.");
    }
}
