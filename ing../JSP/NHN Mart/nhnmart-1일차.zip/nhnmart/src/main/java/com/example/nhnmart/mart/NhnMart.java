package com.example.nhnmart.mart;

import java.util.ArrayList;
import java.util.Scanner;

public class NhnMart {
    private final FoodStand foodStand = new FoodStand();

    public void prepareMart() {
        fillFoodStand();
    }

    private void fillFoodStand() {
        for (int i = 0; i < 3; i++) {
            foodStand.add(new Food("양파", 1_000));
        }
        for (int i = 0; i < 5; i++) {
            foodStand.add(new Food("계란", 5_000));
        }
        for (int i = 0; i < 10; i++) {
            foodStand.add(new Food("파", 500));
        }
        for (int i = 0; i < 20; i++) {
            foodStand.add(new Food("사과", 2_000));
        }
    }

    public Basket getFoodStand(BuyList buyList) {
        ArrayList<String> list = buyList.getItemList();
        Basket basket = new Basket();
        for (int i = 0; i < list.size(); i++) {
            if ((foodStand.getFoodName(list.get(i)))) {
                Food food;
                food = foodStand.getFood(list.get(i));
                basket.add(food);
            }
        }
        return basket;
    }

    public int getCounter(Basket basket) {
        Counter counter = new Counter(basket, foodStand);
        counter.bill();
        return counter.getPrice();
    }

    public Basket provideBasket() {
        return new Basket();
    }
    private static BuyList inputBuyListFromShell() {
        // Scanner에서 buyList 만들기

        // TODO
        Scanner sc = new Scanner(System.in);
        System.out.println("NHN 마트에 오신 것을 환영합니다. 사고 싶은 물건을 골라주세요.");
        String order = sc.nextLine();
        String argu[] = order.split(" ");
        for(String arg : argu){
            System.out.println(arg);
        }
        BuyList buyList = new BuyList();
        for(int i = 0; i<argu.length;i+=2){
            buyList.add(new BuyList.Item(argu[i], Integer.parseInt((argu[i+1]))));
        }

        // buyList.add(new BuyList.Item("계란", 3));

        return buyList;
    }
}
