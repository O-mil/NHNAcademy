package com.example.nhnmart.mart;
import java.util.ArrayList;
import java.util.Iterator;

public class FoodStand {
    private final ArrayList<Food> foods = new ArrayList<>();
    public Iterator<Food> it;
    public void add(Food onion1) {
        foods.add(onion1);
    }
    public void setIt(){
        this.it = foods.iterator();
    }
    public boolean sell(Food food) throws Exception{
        Iterator<Food> it = foods.iterator();
            while(it.hasNext()){
                if(it.next().getName() == food.getName()){
                    it.remove();
                    return true;
                }
            }
        System.out.println("재고가 부족합니다.");
        throw new Exception("재고가 없습니다.");
    }
    public void print(){
        System.out.println(foods);
    }
    public Boolean getFoodName(String name){
        for(int i = 0; i<foods.size();i++){
            if(foods.get(i).getName().equals(name)){
                return true;
            }
        }
        return false;
    }
    public Food getFood(String name){
        for(int i = 0; i<foods.size();i++){
            if(foods.get(i).getName().equals(name)){
                return foods.get(i);
            }
        }
        return null;
    }
    public void size(){
        System.out.println(foods.size());
    }

    public boolean contains(Food food){
        if(foods.contains(food)) return true;
        else return false;
    }

}
