package com.example.nhnmart.mart;

public class Customer {
    private int money=20000;
    // 고객의 구매 목록
    private final BuyList buyList;
    // 고객의 장바구니
    private Basket basket;

    public Customer(BuyList buyList) {
        this.buyList = buyList;
    }

    // 장바구니를 챙김
    public void bring(Basket basket) {
        this.basket = basket;
    }

    public void pickFoods(Basket basket){
        this.basket = basket;
    }
    public void payTox(int price){
        if((this.money - price)<0){
            System.out.println("잔액이 부족합니다");
        }
        else{
            this.money -= price;
            System.out.println("고객님 결제 후 잔액 :"+money+"입니다.");
        }
    }
    public Basket handin(){
        return basket;
    }
}
