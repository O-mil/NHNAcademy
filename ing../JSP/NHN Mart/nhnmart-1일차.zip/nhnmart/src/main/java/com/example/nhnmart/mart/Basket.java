package com.example.nhnmart.mart;
import java.util.ArrayList;
import java.util.Iterator;

public class Basket{
    private final ArrayList<Food> foods = new ArrayList<>();
    public Iterator<Food> it;
    public void add(Food food) {
        foods.add(food);
    }
    public int getSize(){
        return foods.size();
    }
    public Boolean getFoodName(String name){
        for(int i = 0; i<foods.size();i++){
            if(foods.get(i).getName().equals(name)){
                return true;
            }
        }
        return false;
    }
    public Food getFood(String name){
        for(int i = 0; i<foods.size();i++){
            if(foods.get(i).getName().equals(name)){
                return foods.get(i);
            }
        }
        return null;
    }
    public void setIt(){
        this.it = foods.iterator();
    }
}
