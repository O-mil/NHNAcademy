package com.example.nhnmart;

import com.example.nhnmart.mart.Food;
import com.example.nhnmart.mart.FoodStand;
import lombok.extern.slf4j.Slf4j;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@Slf4j
public class FoodServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html");
        resp.setCharacterEncoding("UTF-8");
        FoodStand foodstand = (FoodStand)getServletContext().getAttribute("foodStand");
        foodstand.setIt();
        try (PrintWriter writer = resp.getWriter()) {
            writer.println("<!DOCTYPE html>");
            writer.println("<html>");
            writer.println("<head>");
            writer.println("</head>");
            writer.println("<body>");
            writer.println("<form method=\"post\" action=\"/cart\">");
            writer.println("<ul>");
            int index=1;
                while(foodstand.it.hasNext()){
                    Food food = foodstand.it.next();
                    String product = food.getName();
                    writer.println("<li><input type='checkbox' name='"+product+"' id='"+product+index+"' value='"+product+"'><label for='"+product+index+"'>"+product+"</label></li>\n");
                    index++;
                }
            writer.println("<button type='submit'>전송</button>");
            writer.println("</ul>");
            writer.println("</form>");
            writer.println("</body>");
            writer.println("</html>");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
}