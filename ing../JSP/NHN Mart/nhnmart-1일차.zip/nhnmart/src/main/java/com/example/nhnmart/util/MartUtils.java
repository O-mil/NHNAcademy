package com.example.nhnmart.util;

import com.example.nhnmart.mart.Basket;
import com.example.nhnmart.mart.Food;
import com.example.nhnmart.mart.FoodStand;
import lombok.extern.slf4j.Slf4j;

import javax.servlet.ServletContext;
import java.util.ArrayList;
import java.util.Optional;

@Slf4j
public final class MartUtils {
    static int onionPrice;
    static int eggPrice;
    static int greenOnionPrice;
    static int applePrice;
    private MartUtils() {
        throw new IllegalStateException("Utility class");
    }

    public static void prepare(ServletContext servletContext){
        int price;
        FoodStand foodStand = new FoodStand();
        for (int i = 0; i < 2; i++) {
            onionPrice = Integer.parseInt(servletContext.getInitParameter("onion"));
            foodStand.add(new Food("onion", onionPrice));
        }
        for (int i = 0; i < 5; i++) {
            eggPrice = Integer.parseInt(servletContext.getInitParameter("egg"));
            foodStand.add(new Food("egg", eggPrice));
        }
        for (int i = 0; i < 10; i++) {
            greenOnionPrice = Integer.parseInt(servletContext.getInitParameter("greenOnion"));
            foodStand.add(new Food("greenOnion", greenOnionPrice));
        }
        for (int i = 0; i < 20; i++) {
            applePrice = Integer.parseInt(servletContext.getInitParameter("apple"));
            foodStand.add(new Food("apple", applePrice));
        }
        servletContext.setAttribute("foodStand",foodStand);
    }
    public static void makeBasket(ArrayList<String> list, ServletContext servletContext){
        int totalPrice=0;
        Basket basket = new Basket();
        for(String food : list){
            switch (food){
                case "onion" : basket.add(new Food("onion", onionPrice));totalPrice+=onionPrice;break;
                case "egg" : basket.add(new Food("egg", eggPrice));totalPrice+=eggPrice;break;
                case "greenOnion" : basket.add(new Food("greenOnion", greenOnionPrice));totalPrice+=greenOnionPrice;break;
                case "apple" : basket.add(new Food("apple", applePrice));totalPrice+=applePrice;break;
            }
        }
        log.info(String.valueOf(totalPrice));
        servletContext.setAttribute("totalPrice",totalPrice);
        servletContext.setAttribute("basket",basket);
    }
}
